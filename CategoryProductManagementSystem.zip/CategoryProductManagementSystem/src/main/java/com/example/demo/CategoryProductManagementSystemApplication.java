package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CategoryProductManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(CategoryProductManagementSystemApplication.class, args);
		System.out.println("jai shree ram");
	}

}
